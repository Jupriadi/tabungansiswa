<div class="container h-100">
	<div class="row bg-light mt-2 h-100">
		<div class="col-lg pt-4 text-left h-100" style="overflow: scroll;">
			<h4> <i class="fa fa-list"></i> Data Semua Siswa</h4>
			<hr>
			<a class="btn bg-success text-light" href="#tambahSiswa" data-toggle="modal">
			  <i class="fa fa-plus-circle"></i> Tambah Data
			</a><hr>
			<table class="table table-hover">
				<thead>
					<tr class="bg-success text-light">
						<th width="10%">No</th>
						<th>NIS</th>
						<th>Nama</th>
						<th>Kelamin</th>
						<th>Alamat</th>
						<th>Kelas</th>
						<th>Aksi</th>
					</tr>
				</thead>
				<tbody>
					<?php $no=1; ?>
					<?php foreach($data as $sis): ?>

					<tr>
						<td><?= $no ?></td>
						<td><?= $sis['nis'] ?></td>
						<td><?= $sis['nama'] ?></td>
						<td><?= $sis['kelamin'] ?></td>
						<td><?= $sis['alamat'] ?></td>
						<td><?= $sis['kelas'] ?></td>
						<td>
							<a href="#hapus_<?= $sis['nis']?>" data-toggle="modal" class="btn bg-warning text-light">
								<i class="fa fa-trash-alt"></i>
							</a>
							<a href="#edit_<?= $sis['nis']; ?>" data-toggle="modal" class="btn bg-primary text-light">
								<i class="fa fa-pencil-alt"></i>
							</a>
						</td>
					</tr>

				<div class="modal fade" id="hapus_<?= $sis['nis']?>">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
							</div>
							<div class="modal-body">
								<div class="text-center">
									<i class="text-warning fa fa-question-circle fa-6x"></i><br><br>	
									Apakah Anda Yakin Ingin Menghapus Data..?
									<hr>
								<a href="<?= base_url()."Ccrud/hapusSiswa/?nis=$sis[nis]"; ?>" class="btn btn-outline-primary" >Hapus</a>
								<button data-dismiss="modal" type="button" class="btn btn-outline-danger">Batal</button>
								</div>
							</div>
							<div class="modal-footer">
							</div>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div><!-- /.modal -->

				<!-- modal edit siswa -->
		<div class="modal fade" id="edit_<?= $sis['nis']?>">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title"><i class="fa fa-list"></i> Tambah Data Siswa</h4>
					</div>
					<div class="modal-body">
						<form method="POST" action="<?= base_url('Ccrud/updateSiswa') ?>">
							<div class="form-group row">
								<label for="inputEmail3" class="col-sm-2 form-control-label">NIS</label>
								<div class="col-sm-10">
									<input type="text" name="nis" class="form-control" id="inputEmail3" value="<?= $sis['nis']?>" readonly>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 form-control-label">Nama</label>
								<div class="col-sm-10">
									<input type="text" value="<?= $sis['nama']?>" name="nama" class="form-control" id="inputPassword3" placeholder="Ex: Mr.Jepp" required>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 form-control-label">Kelamin</label>
								<div class="col-lg-2">
									<input class="form-control" type="text" value="<?= $sis['kelamin']; ?>" name="kel">
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 form-control-label">Alamat</label>
								<div class="col-sm-10">
									<textarea name="alamat" class="form-control" ><?= $sis['alamat']; ?></textarea>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 form-control-label">Kelas</label>
								<div class="col-sm-4">
									<select type="text" name="kelas" class="form-control" id="inputPassword3">
										<option value="<?= $sis['kelas']?>"><?= $sis['kelas']?></option>
										<option value="VII">VII</option>
										<option value="VIII">VIII</option>
										<option value="IX">IX</option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
									<button data-dismiss="modal" class="btn btn-danger"><i class="far fa-times-circle"></i> Batal</button>
								</div>
							</div>
						</form>
					</div>
					<div class="modal-footer">
						<span class="text-secondary"> copyright@stmik2019</span>
					</div>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->


					<?php $no++ ?>
					<?php endforeach; ?>
				</tbody>
			</table>
			<hr>
			<div style="margin:-20px" class="bg-dark text-light text-center text-secondary p-5">
				copyright@stmiksznw2019
			</div>
			<hr>
		</div>
	</div>
</div>
