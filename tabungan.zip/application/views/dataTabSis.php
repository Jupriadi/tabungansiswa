
<?php 
	function format_indo($date){
	    $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");

	    $tahun = substr($date, 0, 4);               
	    $bulan = substr($date, 5, 2);
	    $tgl   = substr($date, 8, 2);
	    $result = $tgl . "-" . $BulanIndo[(int)$bulan-1]. "-". $tahun;
	    return($result);
	}
	function hitung_jumlah($juml){

	}
 ?>
<div class="container h-100">
	<div class="row bg-light mt-2 h-100">
		<div class="col-lg container pt-4 text-left h-100" style="overflow: scroll;" >
			<h4 class="container"> <i class="fa fa-list"></i> Data Tabungan Siswa</h4>
			<hr>
			<div class="row container " >
				<div class="col-lg-6">
					
					<?php foreach($data as $d); ?>
					<h4 class="title"><?= $d['nama']." |<small> ".$d['nis']."</small>"; ?></h4>
				</div>
				<div class="col-lg-6 text-right">
					<a target="blank" href="<?= base_url("Ccetak/cetakPersis/?nis=$_GET[nis]") ?>" class="mr-4 btn btn-lg bg-primary text-light"> <i class="fa fa-print"></i> Cetak</a>
				</div>
			</div>
			<?php 
				$jumT=0;
				$cek1=$this->db->get_where('tb_tabungan', array('nis'=>$d['nis']));
				foreach($cek1->result_array() as $c):
					$jumT +=$c["jumlah"];
				endforeach;
				$jumTar=0;
				$cek2=$this->db->get_where('tb_penarikan', array('nis'=>$d['nis']));
				foreach($cek2->result_array() as $c):
					$jumTar +=$c["jumlah"];
				endforeach;
			?>
			<hr>
				Jumlah Tabungan : Rp. <?= number_format($jumT) ?> ||
				Jumlah Penarikan : Rp. <?= number_format($jumTar)?> ||
				<strong>					
					Jumlah Saldo Saat ini : Rp. <?= number_format($jumT-$jumTar) ?>
				</strong>


			<hr>
			<div class="row" >
				<div class="col-lg-6">
					<legend>Data Tabungan</legend>
					<table class="table table-hover">
						<thead>
							<tr class="bg-success text-light">
								<th width="10%">No</th>
								<th>Tanggal</th>
								<th>Penereima</th>
								<th>Jumlah Tabungan</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php $no=1; $jum=0;?>
							<?php foreach($data as $sis): ?>
							<?php
								$nis = $sis['nis'];
							?>
							<tr>
								<td><?= $no ?></td>
								<td><?= format_indo($sis['tanggal']); ?></td>
								<td>Admin</td>
								<td>Rp. <?= number_format($sis['jumlah']) ?></td>
								<td>
									<a target="blank" href="<?= base_url("Ccetak/tabSis/?id=$sis[id_tabungan]") ?>" class="btn bg-success btn-sm text-light">
										<i class="fa fa-print"></i>
									</a>
									<a  href="#tampil_<?= $sis['id_tabungan'] ?>" data-toggle="modal" class="btn btn-sm bg-warning text-light">
										<i class="fa fa-file-invoice-dollar"></i>
									</a>
								</td>
							</tr>
								<div class="modal fade" id="tampil_<?= $sis['id_tabungan'] ?>">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h4 class="modal-title">Data Tabungan</h4>
											</div>
											<div class="modal-body container">
												<div class="container">
													<div class="form-group row">
														<label for="inputEmail3" class="col-sm-2 form-control-label">NIS</label>
														<div class="col-sm-10">
															: <?= $sis['nis']?>
														</div>
													</div>
													<div class="form-group row">
														<label for="inputPassword3" class="col-sm-2 form-control-label">Nama</label>
														<div class="col-sm-10">
															: <?= $sis['nama']?>
														</div>
													</div>
													<div class="form-group row">
														<label class="col-sm-2">Nominal</label>
														<div class="col-sm-10">
															: Rp. <?= number_format($sis['jumlah'])?>
														</div>
													</div>
													<div class="form-group row">
														<div class="col-sm-offset-2 col-sm-10">
															<button type="submit" class="btn btn-primary">Cetak</button>
														</div>
													</div>
												 </div>
											</div>
											<div class="modal-footer">
															copyright@stmiksznw2019
											</div>
										</div>
									</div><!-- /.modal-dialog -->
								</div>  <!-- /.modal -->
							<?php $no++ ?>
							<?php $jum +=$sis["jumlah"]; ?>
							<?php endforeach; ?>
							<tr class="text-center">
								<th colspan="3"> Jumlah Tabungan</th>
								<th colspan="2" class="text-left">Rp. <?= number_format($jum) ?></th>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="col-lg-6">
					<legend> Data Penarikan</legend>
					<table class="table">
						<tr class="bg-success text-light">							
								<th width="10%">No</th>
								<th>Tanggal</th>
								<th>Jumlah Penarikan</th>
						</tr>
						<?php $no2=1; ?>
						<?php foreach($cek2->result_array() as $c2 ): ?>

						<tr>
							<td><?= $no2 ?></td>
							<td><?= format_indo($c2['tanggal']) ?></td>
							<td><?= $c2['jumlah']?></td>
						</tr>

						<?php $no2++; endforeach; ?>

						<tr class="text-center">
							<th colspan="2"> Jumlah Penarikan</th>
							<th  class="text-left">Rp. <?= number_format($jumTar) ?></th>
						</tr>
					</table>
				</div>
			</div>
			<hr>
			<div class="col-lg p-2 mb-5 text-center text-secondary">
				copyright@stmiksznw2019
			</div>
		</div>
	</div>
</div>
