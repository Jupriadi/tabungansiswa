<div class="container h-100">
	<div class="row bg-light mt-2 h-100">
		<div class="col-lg pt-4 text-left h-100" style="overflow: scroll;">
			<h4> <i class="fa fa-list"></i> Data Tabungan Siswa</h4>
			<hr>
			<table class="table table-hover">
				<thead>
					<tr class="bg-success text-light">
						<th width="10%">No</th>
						<th>NIS</th>
						<th>Nama</th>
						<th>Kelamin</th>
						<th>Kelas</th>
						<th>Saldo Saat Ini</th>
						<th>Lihat Detail</th>
					</tr>
				</thead>
				<tbody>
					<?php $no=1; ?>
						
					<?php foreach($data as $sis): ?>
					<?php 
					$jumtab=0;
					$jumtar=0;

						$nis = $sis['nis'];
						$w=array('nis'=> $nis);
						// $sql = "SELECT * from tb_tabungan";
						$cek=$this->db->get_where('tb_tabungan',$w);
						$cek2=$this->db->get_where('tb_penarikan', $w);

						foreach($cek->result_array() as $c):
							$jumtab +=$c["jumlah"];
						endforeach;
						foreach($cek2->result_array() as $c2):
							$jumtar +=$c2["jumlah"];
						endforeach;

						$tabungan=$jumtab-$jumtar;
					 ?>

					<tr>
						<td><?= $no ?></td>
						<td><?= $nis ?></td>
						<td><?= $sis['nama'] ?></td>
						<td><?= $sis['kelamin'] ?></td>
						<td><?= $sis['kelas'] ?></td>
						<td>Rp. <?= number_format($tabungan) ?></td>
						<td>
							<a href="<?= base_url("Chome/?hal=tampTabSis&nis=$nis") ?>" class="btn bg-warning text-light">
								<i class="fa fa-ellipsis-h"></i>
							</a>
						</td>
					</tr>

					<?php $no++ ?>
					<?php endforeach; ?>
				</tbody>
			</table>
			<hr>
		</div>
	</div>
</div>
