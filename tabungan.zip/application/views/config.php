<style type="text/css">
	.fileUpload {
    position: relative;
    overflow: hidden;
    margin: 10px;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
</style>
<div style="padding:20px;background: white;">

	<div class="jumbotron">
		
		<div class="container">
			<?php 
				if(isset($_GET['warn']))
				{
					if($_GET['warn']=='pasword_lama_salah')
					{
			?>
			<div class="alert bg-danger text-light alert-dismissible" role="alert">
			  <strong>Password Lama Tidak Sesuai</strong> || <a href="#hint" data-toggle="modal" class="text-warning">Lupa Password</a>
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
			    <span aria-hidden="true">&times;</span>
			  </button>
			</div>
			<?php 
						
					}
				}else{
					
				}
			?>
			<div class="row">
				<div class="col-lg-3">
					<img src="<?= base_url()."assets/img/gambar/$sesi[gambar]" ?>" width="100%" class="img-responsive" alt="Image">
				</div>
				<div class="col-lg-6 border-primary">
					<h3><?= $sesi['full_name'] ?></h3><hr><hr>
					<div>
						<table class="table">
							<tr>
								<th>Username </th>
								<td > : <?= $sesi['username'] ?></td>
								<td rowspan="3" width="100px" valign="top" class="text-right">
									<a href="#edit" data-toggle="modal" style="margin-top:-20px;font-size:24pt" class="btn btn-lg font-weight-bold text-secondary">
										<i class="fa fa-edit"></i>
									</a>
								</td>
							</tr>
							<tr>
								<th>Password </th>
								<td class="text-danger">: Tidak DItampilkan</td>
							</tr>
						</table>
						<a href="#ganti" data-toggle="modal" class="btn btn-outline-primary">
							<i class="fa fa-camera"></i>
							Ganti Photo
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>

<div class="modal fade" id="hint">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				
			</div>
			<div class="modal-body text-center">
				<i class="fa fa-exclamation-circle fa-5x text-warning"></i>
				<hr>
				<h5>Password Lama Anda Berkaitan Dengan Kata <strong><?= $sesi['hint']; ?></strong>  </h5>
			</div>
			<div class="modal-footer">
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="ganti">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body text-center">
				<label>Ukuran gambar 800pxx1000px di Rekomendasikan</label>
				<img src="<?= base_url()."assets/img/gambar/$sesi[gambar]" ?>" id="gambar_nodin" width="400" alt="Preview Gambar" />
				<form action="<?= base_url('auth/gantiGambar') ?>" method="POST" role="form" enctype="multipart/form-data">
					<input type="hidden" value="<?= $sesi['id_admin'] ?>" name="id_admin">
					<div class="fileUpload btn btn-outline-danger">
						<span><i class="fa fa-camera"></i> Pilih Gambar</span>
						<input name="gambar" id="preview_gambar" class="upload" type="file" />
					</div>
					<button type="submit" class="btn bg-primary text-light"><i class="fa fa-check-circle"></i> Simpan</button>
				</form>
			</div>
			<div class="modal-footer">
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="edit">
	<div class="modal-dialog">
		<div class="modal-content">

			<div class="modal-body">
				<h1 class="text-center text-info">
					<i class="fa fa-cog fa-spin fa-2x"></i>
				</h1>
				<hr>
				<form action="<?= base_url()."auth/ubahConfig" ?>" method="POST">				
					<div class="form-group">
						<input type="hidden" value="<?= $sesi['id_admin'] ?>" name="id_admin">
						<input name="full_name" style="font-size:16pt;border-radius:40px;" type="text" value="<?= $sesi['full_name'] ?>" class="form-control text-center" id="" placeholder="Full Name">
					</div>
					<div class="form-group">
						<input name="username" value="<?= $sesi['username'] ?>" style="font-size:16pt;border-radius:40px;" type="text" class="form-control text-center" id="" placeholder="Username">
					</div><hr>
					<p class="text-center">Biarkan Kosong Jika Tidak Ingin Merubah Password</p>	
					<div class="form-group">
						<input name="password_lama" style="font-size:16pt;border-radius:40px;" type="password" class="form-control text-center" id="" placeholder="Password Lama">
					</div>
					<div class="form-group">
						<input name="password_baru" style="font-size:16pt;border-radius:40px;" type="password" class="form-control text-center" id="" placeholder="Password Baru">
					</div>
					<div class="form-group">
						<input name="kata_bantu" style="font-size:16pt;border-radius:40px;" type="text" class="form-control text-center" id="" placeholder="Kata Bantu">
					</div>
				
					<button type="submit" class="btn btn-lg btn-info btn-block btn-user form-control">
						Simpan Perubahan
					</button>

					<button type="button" data-dismiss="modal" class="btn btn-lg btn-warning text-light btn-block btn-user form-control">
						Batal
					</button>
				</form>
			</div>
			<div class="modal-footer">
				copyright@stmiksznw2019
			</div>
		</div>
	</div>
</div>