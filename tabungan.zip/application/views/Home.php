<div class="container h-100">
	<div class="row text-center h-100">
		<div class=" col-lg-12 bg-light mt-2">
			<h3 class=" mt-5"> Selamat Datang</h3>
			<h4>Aplikasi Tabungan MTs NW Lenek 1</h4	>
			<img class="mt-5" width="200px" src="<?= base_url('/logo.png') ?>">
			<div>
				
			</div>
		<hr>
		<div class="text-center p-4 text-secondary">
			copyright@stmiksznw2019
		</div>
		</div>
	</div>

</div>