<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cetak Tabungan</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?= base_url('./assets/bootstrap/css/bootstrap.min.css') ?>">

		<script type="text/javascript">
			window.print();
		</script>
	</head>
	<body>
<div class="container h-100">
	<div class="row mt-2 h-100">
		<div class="col-lg container pt-4 text-left h-100">
			<hr>
			<div class=" text-center">
				
					<?php foreach($data as $d); ?>
					<h3>Data Tabungan <strong> <?= $d['nama']; ?></strong>	</h3>
			</div>
			<hr>
			<table class="table table-hover">
				<thead>
					<tr>
						<th width="10%">No</th>
						<th>Tanggal</th>
						<th>Penereima</th>
						<th>Kelamin</th>
						<th>Kelas</th>
						<th>Nominal</th>
					</tr>
				</thead>
				<tbody>
					<?php $no=1; $jum=0;?>
					<?php 
						function format_indo($date){
						    $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");

						    $tahun = substr($date, 0, 4);               
						    $bulan = substr($date, 5, 2);
						    $tgl   = substr($date, 8, 2);
						    $result = $tgl . "-" . $BulanIndo[(int)$bulan-1]. "-". $tahun;
						    return($result);
						}

					 ?>
					<?php foreach($data as $sis): ?>
					<?php
						$nis = $sis['nis'];

						
					    $tanggal = format_indo($sis['tanggal']);

					?>
					<tr>
						<td><?= $no ?></td>
						<td><?= $tanggal ?></td>
						<td>Admin</td>
						<td><?= $sis['kelamin'] ?></td>
						<td><?= $sis['kelas'] ?></td>
						<td>Rp. <?= number_format($sis['jumlah']) ?></td>
						
					</tr>
		</div><!-- /.modal -->
					<?php $no++ ?>
					<?php $jum +=$sis["jumlah"]; ?>
					<?php endforeach; ?>
					<tr class="text-center">
						<th colspan="5"> Jumlah Semua</th>
						<th colspan="2" class="text-left">Rp. <?= number_format($jum) ?></th>
					</tr>
				</tbody>
			</table>
			<hr>
			<div class="text-center text-secondary">
				copyright@stmiksznw2019
			</div>
		</div>
	</div>
</div>

	</body>
</html>