		<div class="modal fade" id="tambahSiswa">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title"><i class="fa fa-list"></i> Tambah Data Siswa</h4>
					</div>
					<div class="modal-body">
						<form method="POST" action="<?= base_url('Ccrud/tambahSiswa') ?>">
							<div class="form-group row">
								<label for="inputEmail3" class="col-sm-2 form-control-label">NIS</label>
								<div class="col-sm-10">
									<input type="text" name="nis" class="form-control" id="inputEmail3" placeholder="Ex.:1123xxxxxx" required>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 form-control-label">Nama</label>
								<div class="col-sm-10">
									<input type="text" name="nama" class="form-control" id="inputPassword3" placeholder="Ex: Mr.Jepp" required>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 form-control-label">Kelamin</label>
								<div class="col-sm-10">
									<input class="ml-2" type="radio" name="kel" value="pr"> Perempuan &nbsp &nbsp
									<input type="radio" name="kel" value="lk"> Laki-laki
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 form-control-label">Alamat</label>
								<div class="col-sm-10">
									<textarea name="alamat" class="form-control" id="inputPassword3" placeholder="Ex: Mr.Jepp" required></textarea>
								</div>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-2 form-control-label">Kelas</label>
								<div class="col-sm-4">
									<select type="text" name="kelas" class="form-control" id="inputPassword3">
										<option value="VII">-Pilih Kelas</option>
										<option value="VII">VII</option>
										<option value="VIII">VIII</option>
										<option value="IX">IX</option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
									<button data-dismiss="modal" class="btn btn-danger"><i class="far fa-times-circle"></i> Batal</button>
								</div>
							</div>
						</form>
					</div>
					<div class="modal-footer">
						<span class="text-secondary"> copyright@stmik2019</span>
					</div>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->

<!-- modal logout -->
				<div class="modal fade" id="logout">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
							</div>
							<div class="modal-body">
								<div class="text-center">
									<i class="fa fa-question-circle fa-6x"></i><br><br>	
									Apakah Anda Yakin Ingin Keluar..?
									<hr>
								<a href="<?= base_url('auth/logout') ?>" class="btn btn-outline-primary">Keluar</a>
								<button data-dismiss="modal" type="button" class="btn btn-outline-danger">Batal</button>
								</div>
							</div>
							<div class="modal-footer">
							</div>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div><!-- /.modal -->
				<div class="modal fade" id="tentang">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
							</div>
							<div class="modal-body">
								<div class="text-center">
									<img src="<?= base_url('./logostmik.jpg') ?>" width=" 100px" />
								</div>
								<hr>
								<div class="text-center">
									<strong>Aplikasi Tabungan Siswa ini</strong> di buta dlam rangka menyelesaikan tugas laporan Praktik Kerja Lapangan (PKL), Sekolah Tinggi Manajemen Informatika (STMIK) Syaikh Zainuddin Nahdlatul Wathan Anjani Lombok Timur, oleh <strong>Titi Supianti</strong> peserta PKL yang bertempat di MTs NW Lenek 1, aplikasi ini juga sebagai persembahan untuk MTs NW Lenek Satu Semoga Bisa digunakan sebagaimana mestinya.
								</div>
							</div>
							<div class="modal-footer">
							</div>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div><!-- /.modal -->