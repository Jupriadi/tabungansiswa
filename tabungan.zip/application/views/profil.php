<div class="container h-100">
	<div class="row bg-light mt-2 h-100">
		<div class="col-lg container pt-5 h-100" style=" overflow: scroll">
			<div class="row container">
				<div class="col-lg container">
					<h3 class="text-danger"> <i class="fa fa-user fa-2x"></i> Profil Admin</h3>
					<hr>
				</div>
			</div>
			<?php include"config.php"; ?>
		</div>
	</div>
</div>
