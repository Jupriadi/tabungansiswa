<div class="container h-100">
	<div class="row bg-light mt-2 h-100">
		<div class="col-lg container pt-5 h-100">
			<div class="row">
				<div class="col-lg-3">
					
				</div>
				<div class="col-7">
					<h3 class="text-center text-success"> <i style="border:2px solid green;border-radius:150px;padding:30px" class="fa fa-hand-holding-heart fa-4x"></i> <br>Penarikan</h3>
					<hr>
					<?php 
						if(!isset($_GET['nis']))
						{
							include"formpenarikan.php";
						}else{
							include"prosespenarikan.php";
						}
					?>
				</div>
			</div>
		</div>
	</div>
</div>
