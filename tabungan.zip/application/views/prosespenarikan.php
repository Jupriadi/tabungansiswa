<?php
	$jumtab=0;
	$jumtar=0;

	$nis = $_GET['nis'];
	$w=array('nis'=> $nis);
	// $sql = "SELECT * from tb_tabungan";
	$cek=$this->db->get_where('tb_tabungan',$w);
	foreach($cek->result_array() as $c):
		$jumtab +=$c["jumlah"];
	endforeach;
	$tar=$this->db->get_where('tb_penarikan',$w);
	foreach($tar->result_array() as $t):
		$jumtar +=$t["jumlah"];
	endforeach;

	$jum=$jumtab-$jumtar;

	$cek2=$this->db->get_where('tb_siswa', $w)->row_array();
?>
<form method="POST" action="<?= base_url('Ccrud/penarikan')?>">
	<input type="hidden" name="nis" value="<?= $nis ?>">
	<legend class="text-center">Prose Penarikan Tabungan Siswa</legend>
	<div class="form-group row">
		<div class="col-lg">
			
			<h4 class="text-center"><?= $cek2['nama'] ?></h4>
		</div>
	</div>
	<div class="form-group row">
		<label for="inputEmail3" class="text-right col-sm-4 form-control-label">
			Jumlah Tabungan Siswa
		</label>
		<div class="col-sm-5">
			<input type="text" class="form-control" value="Rp. <?= number_format($jum) ?>" readonly>
		</div>
	</div>
	<div class="form-group row">
		<label for="inputEmail3" class="text-right col-sm-4 form-control-label">
			Jumlah Ditarik
		</label>
		<div class="col-sm-5">
			
								<div class="input-group mb-3">
								  <div class="input-group-prepend">
								    <span class="input-group-text" id="basic-addon1">Rp.</span>
								  </div>
								  <input type="number" class="form-control" name="nominalTarik" aria-describedby="basic-addon1">
								</div>
		</div>
	</div>
	<div class="form-group row">
		<label for="inputEmail3" class="text-right col-sm-4 form-control-label">
			
		</label>
		<div class="col-sm-5 text-danger">
			<p style="margin-top:-18px;font-size:11px"> Nominal Penarikan tidak boleh lebih dari tabungan</p>
		</div>
	</div>

	<div class="form-group row">
		<div class="col-sm-4"></div>
		<div class="col-sm-5">
			<button type="submit" class="btn bg-primary text-light">Poses
				<i class="fa fa-angle-right"></i>
			</button>
			<a href="?hal=penarikan" type="submit" class="btn bg-danger text-light">Batal
			</a>
		</div>
	</div>
</form>