<form method="GET" action="">
	<input type="hidden" name="hal" value="penarikan">
	<div class="form-group row">
		<label for="inputEmail3" class="text-right col-sm-4 form-control-label">
			Pilih Siswa
		</label>
		<div class="col-sm-5">
			<select onchange="isi_otomatis()" class="form-control" name="nis" id="nis" required>
				<option>--Pilih Siswa</option>
				<?php foreach($data as $d): ?>
					<option value="<?= $d['nis']?>"><?= $d['nis']."-".$d['nama']?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>
	<div class="row text-danger text-center">
		<div class="col-lg">
			
		</div>
	</div>

	<div class="form-group row">
		<div class="col-sm-4"></div>
		<div class="col-sm-5">
			<button type="submit" class="btn bg-primary text-light">Poses
				<i class="fa fa-angle-right"></i>
			</button>
		</div>
	</div>
</form>