<div class="container h-100">
	<div class="row bg-light mt-2 h-100">
		<div class="col-lg container pt-5 h-100">
			<div class="row">
				<div class="col-lg-3">
					
				</div>
				<div class="col-7">
					<h3 class="text-center text-danger"> <i style="border:2px solid salmon;border-radius:100px;padding:30px" class="fa fa-hand-holding-usd fa-4x"></i> <br>Menabung</h3>
					<hr>
					<form method="POST" action="<?= base_url('Ccrud/tabung')?>">
						<div class="form-group row">
							<label for="inputEmail3" class="text-right col-sm-4 form-control-label">
								Pilih Siswa
							</label>
							<div class="col-sm-5">
								<select class="form-control" name="siswa" required>
									<option>--Pilih Siswa</option>
									<?php foreach($data as $d): ?>
										<option value="<?= $d['nis']?>"><?= $d['nis']."-".$d['nama']?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="form-group row">
							<label for="inputEmail3" class="text-right col-sm-4 form-control-label">
								Nominal Tabungan
							</label>
							<div class="col-sm-5">
								<div class="input-group mb-3">
								  <div class="input-group-prepend">
								    <span class="input-group-text" id="basic-addon1">Rp.</span>
								  </div>
								  <input type="number" class="form-control" name="jumlah" aria-describedby="basic-addon1">
								</div>
							</div>
						</div>

						<div class="form-group row">
							<div class="col-sm-4"></div>
							<div class="col-sm-5">
								<button type="submit" class="btn bg-primary text-light">Poses
									<i class="fa fa-angle-right"></i>
								</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
