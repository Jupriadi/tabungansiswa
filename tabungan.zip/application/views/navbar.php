<nav class="navbar navbar-expand-lg navbar-dark bg-danger ">
  <div class="container">
  <a class="navbar-brand" href="<?= base_url('chome') ?>"><i class="fa fa-tachometer-alt"></i> Beranda</a>
  

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="?hal=datasiswa"> <i class="fa fa-users"></i> Data Siswa <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdown" data-toggle="dropdown" href="#" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-funnel-dollar"></i> Proses</a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="?hal=menabung"><i class="fa fa-donate"></i> Menabung</a>
          <a class="dropdown-item" href="?hal=penarikan"><i class="fa fa-money-check-alt"></i> Penarikan</a>
          <div class="dropdown-divider"></div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?hal=data_tabungan"> <i class="fa fa-money-check"></i> Data tabungan</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <ul class="navbar-nav mr-auto">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdown" data-toggle="dropdown" href="#" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-user"></i>
          <?= $sesi['username'] ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a  href="#tentang" class="dropdown-item text-dark" data-toggle="modal"><i class="fa fa-users"></i> Tentang</a>
          <a class="dropdown-item" href="?hal=profil"><i class="fa fa-cogs"></i> Profil Admin</a>
          <div class="dropdown-divider"></div>

          <a href="#logout" class="dropdown-item text-dark" data-toggle="modal"><i class="fa fa-power-off"></i> Keluar</a>
        </div>
      </li>
    </form>
  </div>
  </div>
</nav>