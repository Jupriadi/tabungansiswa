
<script type="text/javascript" src="<?php echo base_url('assets/jquery.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-ui.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/popper.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<script type="text/javascript">

function bacaGambar(input) {
   if (input.files && input.files[0]) {
      var reader = new FileReader();
 
      reader.onload = function (e) {
          $('#gambar_nodin').attr('src', e.target.result);
      }
 
      reader.readAsDataURL(input.files[0]);
   }

}

	$("#preview_gambar").change(function(){
	   bacaGambar(this);
	});
</script>
</body>
</html>