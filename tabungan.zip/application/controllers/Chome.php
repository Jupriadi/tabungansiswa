<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chome extends CI_Controller {

	public function index()
	{
		$sesi = $log['admin'] = $this->db->get_where('admin',['username' => $this->session->userdata('username')])->row_array();
		if($sesi){
			
		$this->load->view('header');
		$this->load->view('navbar',array('sesi'=> $sesi));
		}else{
			redirect('auth');
		}


		if(isset($_GET['hal']))
		{
			if($_GET['hal']=='datasiswa'){
				$data=$this->model->getSiswa();
				$this->load->view('datasiswa',array('data' => $data));
			}elseif($_GET['hal']=='menabung'){
				
				$data=$this->model->getSiswa();
				$this->load->view('menabung',array('data' => $data));

			}elseif($_GET['hal']=='data_tabungan'){

				$data=$this->model->getTab();
				$this->load->view('dataTabungan',array('data' => $data));

			}elseif($_GET['hal']=='tampTabSis'){
				$nis=$_GET['nis'];
				$data=$this->model->getTabSis($nis);
				$this->load->view('dataTabSis',array('data' => $data));

			}elseif($_GET['hal']=='penarikan'){
				
				$data=$this->model->getTab();
				$this->load->view('penarikan',array('data' => $data));

			}elseif($_GET['hal']=='profil'){
				
				$this->load->view('profil');

			}else{

			}
		}else{
			
				$this->load->view('home');
		}
		$this->load->view('modal');
		$this->load->view('footer');
	}
}

/* End of file Chome.php */
/* Location: ./application/controllers/Chome.php */