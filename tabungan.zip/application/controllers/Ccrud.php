<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ccrud extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
	}

	public function tambahSiswa()
	{
		$sesi = $log['admin'] = $this->db->get_where('admin',['username' => $this->session->userdata('username')])->row_array();
		if($sesi){
			
		}else{
			redirect('auth');
		}

		$data = array(
				'nis' => $this->input->post('nis'),
				'nama' => $this->input->post('nama'),
				'kelamin' => $this->input->post('kel'),
				'alamat' => $this->input->post('alamat'),
				'kelas' => $this->input->post('kelas')
			);
		$tambah = $this->model->tambahSiwa($data);
		if ($tambah)
		{
			redirect('chome/?hal=datasiswa&&per=berhasil');

		}else{
			
			redirect('chome/?hal=datasiswa&&per=Gagal');
		}
	}
	public function hapusSiswa(){
		$sesi = $log['admin'] = $this->db->get_where('admin',['username' => $this->session->userdata('username')])->row_array();
		if($sesi){
			
		}else{
			redirect('auth');
		}
		$nis=$_GET['nis'];

		$whr=array('nis' => '$nis');
		$hapus=$this->db->where('nis', $nis);
		$hapus=$this->db->delete('tb_siswa');
		if ($hapus)
		{
			redirect('chome/?hal=datasiswa&&per=berhasil');

		}else{
			
			redirect('chome/?hal=datasiswa&&per=Gagal');
		}
	}
	public function updateSiswa(){
		$sesi = $log['admin'] = $this->db->get_where('admin',['username' => $this->session->userdata('username')])->row_array();
		if($sesi){
			
		}else{
			redirect('auth');
		}
		$nis = $this->input->post('nis');
		$whr = array('nis' => $nis);
		$data = array(
				'nama' => $this->input->post('nama'),
				'kelamin' => $this->input->post('kel'),
				'alamat' => $this->input->post('alamat'),
				'kelas' => $this->input->post('kelas')
			);
		$update = $this->model->updateSiswa($data,$whr);
		if ($update)
		{
			redirect('chome/?hal=datasiswa&&per=berhasil');

		}else{
			
			redirect('chome/?hal=datasiswa&&per=Gagal');
		}
	}
	public function tabung(){
		$sesi = $log['admin'] = $this->db->get_where('admin',['username' => $this->session->userdata('username')])->row_array();
		if($sesi){
			
		}else{
			redirect('auth');
		}
		$nis=$this->input->post('siswa');
		$tabung = array(
			'nis' => $nis,
			'jumlah' => $this->input->post('jumlah'),
			'tanggal' => date('Y-m-d')
		);

		$proses=$this->db->insert('tb_tabungan',$tabung);
		if($proses)
		{
			redirect("/Chome/?hal=tampTabSis&nis=$nis");
		}else{
			redirect("Chome/?hal=data_tabungan&nis=$nis&&data=gagal");
		}
	}
	public function penarikan(){
		$sesi = $log['admin'] = $this->db->get_where('admin',['username' => $this->session->userdata('username')])->row_array();
		if($sesi){
			
		}else{
			redirect('auth');
		}
		$nis=$this->input->post('nis');
		$tabung = array(
			'nis' => $nis,
			'jumlah' => $this->input->post('nominalTarik'),
			'tanggal' => date('Y-m-d')
		);

		$proses=$this->db->insert('tb_penarikan',$tabung);
		if($proses)
		{
			redirect("/Chome/?hal=tampTabSis&nis=$nis");
		}else{
			redirect("Chome/?hal=data_tabungan&nis=$nis&&data=gagal");
		}
	}

}

/* End of file Ccrud.php */
/* Location: ./application/controllers/Ccrud.php */