<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->form_validation->set_rules('user','Username','required|trim');
		$this->form_validation->set_rules('pass','Password','required|trim|min_length[5]');
		if( $this->form_validation->run() == false){
			$this->load->view('auth/index');			
		}else{
			$this->login();
		}
	}
	private function login(){
		$user = $this->input->post('user');
		$password = $this->input->post('pass');

		$cekUs = $this->db->get_where('admin',['username' => $user])->row_array() ;
		
		if($cekUs)
		{
			if(password_verify($password, $cekUs['password']))
			{
				$log=[
					'username' => $cekUs['username'],
					'password' => $cekUs['password']
				];
				$this->session->set_userdata($log);
				redirect('Chome');
			}else{

			$this->session->set_flashdata('message','<div class="alert alert-danger">Wrong Password.!!!</div>') ;
			redirect('auth/index');
			}
		}
		else
		{
			$this->session->set_flashdata('message','<div class="alert alert-danger">Wrong Username.!!!</div>') ;
			redirect('auth/index');
		}

	}
	public function logout()
	{
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('password');
		redirect('auth');
	}

	public function ubahConfig()
	{
		$id=$this->input->post('id_admin');
		$full=$this->input->post('full_name');
		$user=$this->input->post('username');
		$passBaru= $this->input->post('password_baru');
		$passLama=$this->input->post('password_lama');
		$hint=$this->input->post('kata_bantu');

		if($passBaru == "" or $passLama == "" )
		{
			$set= array(
				'full_name' => $full,
				'username' => $user
			);
			$where = array('id_admin' => $id );
			$upd = $this->db->update('admin',$set, $where);
			if($upd){
				redirect('Chome/?hal=profil&warn=profil_updated','refresh');
			}else{
				echo"Gagal Update";
			}

		}else{
			$where = array('id_admin' => $id);
			$ambilPassLama=$this->db->get_where('admin',$where)->row_array();
			if(password_verify($passLama, $ambilPassLama['password']) )
			{
				$set= array(
					'full_name' => $full,
					'username' => $user,
					'password' => password_hash($passBaru,PASSWORD_DEFAULT),
					'hint' => $hint
				);
				$where = array('id_admin' => $id );
				$upd = $this->db->update('admin',$set, $where);
				if($upd){
					redirect('Chome/?hal=profil&warn=profil_updated','refresh');
				}else{
					echo"Gagal Update";
				}
				
			}
			else
			{
				redirect('Chome/?hal=profil&warn=pasword_lama_salah');
			}
		}
	}

	public function gantiGambar(){
		
		$id=$this->input->post('id_admin');

		$upload_image = $_FILES['gambar']['name'];

		 if($upload_image) {
		 	$config['allowed_types'] = 'gif|jpg|png';
		 	$config['upload_path'] = './assets/img/gambar/';

		 	$this->load->library('upload', $config);

		 	if($this->upload->do_upload('gambar')){
		 		$new_image = $this->upload->data('file_name');
		 	}else{
		 		$new_image="logostmik.jpg";
		 	}
		 }else{
		 	$new_image="logostmik.jpg";	
		 }

		$where=array('id_admin' => $id);
		$set=array('gambar' => $new_image);
		$upd=$this->db->update('admin', $set, $where);
		if($upd)
		{
			redirect('Chome/?hal=profil');
		}else{
			echo"gagal update gambar";
		}

	}

}

/* End of file contCetak.php */
/* Location: ./application/controllers/contCetak.php */