<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ccetak extends CI_Controller {
	public function index(){
		$sesi = $log['admin'] = $this->db->get_where('admin',['username' => $this->session->userdata('username')])->row_array();
		if($sesi){
			
		}else{
			redirect('auth');
		}
	}
	public function tabSis(){
		$sesi = $log['admin'] = $this->db->get_where('admin',['username' => $this->session->userdata('username')])->row_array();
		if($sesi){
			
		}else{
			redirect('auth');
		}
		$id=$_GET['id'];
		$whr=array('id_tabungan' => $id);
		$data = $this->model->cetakTab($id);

		$this->load->view('cetakTab',array('data' => $data));
	}
	public function cetakPersis()
	{
		$sesi = $log['admin'] = $this->db->get_where('admin',['username' => $this->session->userdata('username')])->row_array();
		if($sesi){
			
		}else{
			redirect('auth');
		}

		$nis=$_GET['nis'];
		$data = $this->model->cetakPersis($nis);

		$this->load->view('cetakPersis',array('data' => $data));
	}

}

/* End of file contCetak.php */
/* Location: ./application/controllers/contCetak.php */