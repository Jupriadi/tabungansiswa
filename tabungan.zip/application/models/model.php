<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model extends CI_Model {

	public function getSiswa(){
		$data=$this->db->get('tb_siswa');
		return $data->result_array();
	}
	public function tambahSiwa($data)
	{
		$this->db->insert('tb_siswa', $data);
	}
	public function updateSiswa($data,$whr)
	{
		$this->db->update('tb_siswa', $data,$whr);
	}
	public function getTab()
	{

		$data = $this->db->query("SELECT * FROM tb_siswa,tb_tabungan WHERE tb_siswa.nis = tb_tabungan.nis group by tb_siswa.nis");
		return $data->result_array();
	}

	public function getTabSis($nis)
	{

		$data=$this->db->query("SELECT * FROM tb_siswa,tb_tabungan where tb_siswa.nis = tb_tabungan.nis and tb_tabungan.nis='$nis' ");
		return $data->result_array();
	}
	public function cetakTab($id)
	{
		$data = $this->db->query("SELECT * FROM tb_tabungan,tb_siswa where tb_siswa.nis=tb_tabungan.nis and tb_tabungan.id_tabungan = '$id' ");
		return $data->result_array();
	}
	public function cetakPersis($nis)
	{
		$data = $this->db->query("SELECT * FROM tb_tabungan,tb_siswa where tb_siswa.nis=tb_tabungan.nis and tb_siswa.nis = '$nis' ");
		return $data->result_array();
	}

}

/* End of file model.php */
/* Location: ./application/models/model.php */